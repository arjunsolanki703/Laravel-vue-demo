<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\API\RegisterController;
use App\Http\Controllers\API\AccountSettingController;
use App\Http\Controllers\API\ProjectsController;


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::post('register', [RegisterController::class, 'register']);
Route::post('login', [RegisterController::class, 'login']);
Route::post('logout', [RegisterController::class,'logout'])->name('logout');

Route::middleware('auth:api')->group(function () {
    // Route::get('user', 'PassportController@details');
    // Account settings
    Route::post('add-account',[AccountSettingController::class, 'add']);
    Route::get('get-account', [AccountSettingController::class, 'get']);
    Route::get('get-account/{id}', [AccountSettingController::class, 'getAccountById']);
    Route::put('update-account/{id}', [AccountSettingController::class, 'update']);
    Route::delete('delete-account/{id}', [AccountSettingController::class, 'deleteAccount']);

    // Projects
    Route::post('add-project',[ProjectsController::class, 'store']);
    Route::get('get-project', [ProjectsController::class, 'index']);
    Route::get('get-project/{id}', [ProjectsController::class, 'getProjectById']);
    Route::put('update-project/{id}', [ProjectsController::class, 'update']);
    Route::delete('delete-project/{id}', [ProjectsController::class, 'destroy']);
});
