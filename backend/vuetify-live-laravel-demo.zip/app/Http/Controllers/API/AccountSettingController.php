<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Models\AccountSetting;

class AccountSettingController extends Controller
{
    public function get()
    {
        $account_data = new \stdClass();
        $account_data = AccountSetting::where('user_id',Auth::user()->id)->get();
        $account_data = [];
        if ($account_data == null || $account_data == '') {
            return response()->json(["status" => false, "message" => 'Record not found', 'data' => $account_data]);
        }
        try {
            return response()->json(["status" => true, "message" => 'Data Found', "data" => $account_data]);
        } catch (\Throwable $th) {
            $error_code = $th->getCode();
            return response()->json(["status" => false, "message" => 'Result not found..!', 'data' => $account_data]);
        } catch (\Exception $ex) {
            $error_code = $ex->getCode();
            return response()->json(["status" => false, "message" => $ex->getMessage(), 'data' => $account_data]);
        }
    }

    public function add(Request $request)
    {
        if (!Auth::user()->id) {
            return response()->json(["status" => false, "message" => 'Authentication is requried']);
        }
        if ($request->password!=$request->confirm_password) {
            return response()->json(["status" => false, "message" => 'Password and Confirm password does not match..!']);
        }

        $account_info = AccountSetting::where('user_id',Auth::user()->id)->first();
        if ($account_info!='' || $account_info!=null) {
            $data = array(
                "user_id"=>Auth::user()->id,
                "fname"=> $request->fname,
                "lname"=> $request->lname,
                "company"=> $request->company,
                "email"=> $request->email,
                "address"=> $request->address,
                "city"=> $request->city,
                "state"=> $request->state,
                "zip"=> $request->zip,
                "phone"=> $request->phone,
                "website"=> $request->website,
                "password"=> bcrypt($request->password),
                "email_notification"=> $request->email_notification,
                "internal_notification"=> $request->internal_notification,
            );
            AccountSetting::where('id', $account_info->id)->update($data);
            $account_info = AccountSetting::findOrfail($account_info->id);
            return response()->json(["status" => true, "message" => 'Record updated successfully', "data" => $account_info]);
        }

        $account_data = new \stdClass();
        $data = array(
            "user_id"=>Auth::user()->id,
            "fname"=> $request->fname,
            "lname"=> $request->lname,
            "company"=> $request->company,
            "email"=> $request->email,
            "address"=> $request->address,
            "city"=> $request->city,
            "state"=> $request->state,
            "zip"=> $request->zip,
            "phone"=> $request->phone,
            "website"=> $request->website,
            "password"=> bcrypt($request->password),
            "email_notification"=> $request->email_notification,
            "internal_notification"=> $request->internal_notification,
        );
        try {
            $account_data = [];
            $accounts = AccountSetting::create($data);

            return response()->json(["status" => true, "message" => 'Data stored successfully..!', "data" => $accounts]);
        } catch (\Throwable $th) {
            $error_code = $th->getCode();
            return response()->json(["status" => false, "message" => 'Data not stored..!', 'error' => $th]);
        } catch (\Exception $ex) {
            $error_code = $ex->getCode();
            return response()->json(["status" => false, "message" => $ex->getMessage(), 'data' => $account_data]);
        }
    }

    public function getAccountById($id)
    {
        $account_data = new \stdClass();
        $account_data = AccountSetting::find($id);
        $account_data = [];
        if ($account_data == null || $account_data == '') {
            return response()->json(["status" => false, "message" => 'Record not found', 'data' => $response_data]);
        }
        try {
            return response()->json(["status" => true, "message" => 'Data Found', "data" => $account_data]);
        } catch (\Throwable $th) {
            $error_code = $th->getCode();
            return response()->json(["status" => false, "message" => 'Result not found..!', 'data' => $response_data]);
        } catch (\Exception $ex) {
            $error_code = $ex->getCode();
            return response()->json(["status" => false, "message" => $ex->getMessage(), 'data' => $response_data]);
        }
    }

    public function update(Request $request, $id)
    {
        $account_data = new \stdClass();
        $account_info = AccountSetting::find($id);
        $account_data = [];
        if ($account_info == null || $account_info == '') {
            return response()->json(["status" => false, "message" => 'Data Not Found', 'data' => $account_data]);
        }

        $data = array(
            "user_id"=>Auth::user()->id,
            "fname"=> $request->fname,
            "lname"=> $request->lname,
            "company"=> $request->company,
            "email"=> $request->email,
            "address"=> $request->address,
            "city"=> $request->city,
            "state"=> $request->state,
            "zip"=> $request->zip,
            "phone"=> $request->phone,
            "website"=> $request->website,
            "password"=> bcrypt($request->password),
            "email_notification"=> $request->email_notification,
            "internal_notification"=> $request->internal_notification,
        );

        try {
            $account_data = [];
            AccountSetting::where('id', $id)->update($data);
            $account_info = AccountSetting::findOrfail($id);
            return response()->json(["status" => true, "message" => 'Record updated successfully', "data" => $account_info]);
        } catch (\Throwable $th) {
            $error_code = $th->getCode();
            return response()->json(["status" => false, "message" => $th->getMessage(), 'data' => $account_data]);
        } catch (\Exception $ex) {
            $error_code = $ex->getCode();
            return response()->json(["status" => false, "message" => $ex->getMessage(), 'data' => $account_data]);
        }
    }

    public function deleteAccount($id)
    {
        $account_data = new \stdClass();
        try {
            $account_data = [];
            AccountSetting::where('id', $id)->delete();
            return response()->json(["status" => true, "message" => 'Record deleted successfully']);
        } catch (\Throwable $th) {
            $error_code = $th->getCode();
            return response()->json(["status" => false, "message" => $th->getMessage(), 'data' => $account_data]);
        } catch (\Exception $ex) {
            $error_code = $ex->getCode();
            return response()->json(["status" => false, "message" => $ex->getMessage(), 'data' => $account_data]);
        }
    }
}