<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use App\Models\User;
use Tests\TestCase;

class AuthenticationTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    /* public function test_example()
    {
        $response = $this->get('/');

        $response->assertStatus(200);
    } */

    use RefreshDatabase;

    public function testRequiredFieldsForLogin()
    {
        $this->json('POST', 'api/login', ['Accept' => 'application/json'])
            ->assertStatus(422)
            ->assertJson([
                "message" => "The given data was invalid.",
                "errors" => [
                    "name" => ["The name field is required."],
                    "password" => ["The password field is required."],
                ]
            ]);
    }

    public function testSuccessfulLogin()
    {
        $user = User::factory()->create([
            "name" => "admin",
            "email" => "admin@gmail.com",
            'password' => bcrypt('12345678'),
         ]);
        $userData = [
            "name" => "admin",
            "password" => "12345678",
        ];

        $res = $this->json('POST', 'api/login', $userData, ['Accept' => 'application/json']);
        $res->assertStatus(200)
        ->assertJsonStructure([
           "user" => [
               'id',
               'name',
               'email',
               'email_verified_at',
               'created_at',
               'updated_at',
           ],
            "access_token",
            "message"
        ]);
        $this->assertAuthenticated();
    }
}