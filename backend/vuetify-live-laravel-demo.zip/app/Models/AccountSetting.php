<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AccountSetting extends Model
{
    use HasFactory;
    protected $fillable = [
        'user_id',
        'fname',
        'lname',
        'company',
        'email',
        'address',
        'city',
        'state',
        'zip',
        'phone',
        'website',
        'password',
        'email_notification',
        'internal_notification',
    ];
    protected $hidden = [
        'password',
    ];
}