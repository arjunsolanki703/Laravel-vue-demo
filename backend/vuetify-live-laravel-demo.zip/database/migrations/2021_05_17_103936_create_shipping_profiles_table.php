<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateShippingProfilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('shipping_profiles', function (Blueprint $table) {
            $table->id();
            $table->string('profile_name',255);
            $table->string('contact_name',255);
            $table->text('type_address');
            $table->string('type_city',100);
            $table->string('type_state',100);
            $table->string('zip',100);
            $table->string('type_country',100);
            $table->string('firm_email',255);
            $table->string('firm_phone_number',25);
            $table->string('ext');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('shipping_profiles');
    }
}